module.exports = {
  theme: {
    extend: {
      fontFamily: {
        manrope: "--var(font-manrope)",
      },
    },
  },
};
