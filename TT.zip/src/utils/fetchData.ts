import { MOCK_DATA_PATIENTS } from "../consts/consts";

export const fetchData = async () => {
  const username = process.env.AUTH_USERNAME;
  const password = process.env.AUTH_PASSWORD;
  const creds = Buffer.from(`${username}:${password}`).toString("base64");
  const res = await fetch(
    "https://fedskillstest.coalitiontechnologies.workers.dev",
    {
      method: "GET",
      headers: {
        Authorization: `Basic ${creds}`,
        "Content-Type": "application/json",
      },
      cache: "no-store",
    }
  );
  if (!res.ok) {
    throw new Error("Failed to fetch data");
  }
  return res.json();

  // return MOCK_DATA_PATIENTS;
};
