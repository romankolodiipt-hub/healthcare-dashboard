import { PatientsDiagnosisHistory, ChartData } from "@/src/types/types";

export const convertToSlug = (text: string): string => {
  return text.replace(/\s+/g, "-").toLowerCase();
};

export const getDataForChart = (
  diagnosisHistory: PatientsDiagnosisHistory[]
): ChartData => {
  return diagnosisHistory.reduce<ChartData>(
    (acc, item) => ({
      months: [...acc.months, `${item.month.slice(0, 3)}, ${item.year}`],
      diastolicValues: [
        ...acc.diastolicValues,
        item.blood_pressure.diastolic.value,
      ],
      systolicValues: [
        ...acc.systolicValues,
        item.blood_pressure.systolic.value,
      ],
    }),
    {
      months: [],
      diastolicValues: [],
      systolicValues: [],
    }
  );
};

export const convertDate = (dateStr: string): string => {
  const date = new Date(dateStr);

  return date.toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  });
};
