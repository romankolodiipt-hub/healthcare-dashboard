"use client";

import { useContext } from "react";
import { Patient } from "@/src/types/types";
import { UserCard } from "./UserCard";
import { usePathname } from "next/navigation";
import Link from "next/link";
import { PatientsContext } from "../context/Context";
import { convertToSlug } from "../utils/utils";

export const Patients = () => {
  const patients: Patient[] = useContext(PatientsContext);
  const pathName = usePathname();
  return (
    <aside className="min-w-[368px] bg-white rounded-2xl flex flex-col pb-5">
      <div className="flex items-center justify-between p-5 pb-10">
        <h2 className="card-title-24pt">Patients</h2>
        <button className="cursor-pointer">
          <img
            src="/icons/search.svg"
            alt="search"
            className="w-[18px] h-[18px]"
          />
        </button>
      </div>
      <nav className="flex-1 overflow-y-auto mr-1 ">
        <ul>
          {patients.map(({ name, age, gender, profile_picture }: Patient) => {
            const slug = convertToSlug(name);
            return (
              <li
                key={slug}
                className={`flex items-center justify-between p-4 pr-5 cursor-pointer ${
                  pathName.includes(slug) ? "bg-[#D8FCF7]" : ""
                }`}
              >
                <Link
                  href={`/patients/${slug}`}
                  className="flex-1 flex items-center justify-between"
                >
                  <UserCard
                    name={name}
                    description={`${gender}, ${age}`}
                    img={profile_picture}
                  />
                  <img
                    src="/icons/more_horiz.svg"
                    alt="More"
                    className="h-[18px] w-[18px]"
                  />
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </aside>
  );
};
