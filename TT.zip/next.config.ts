import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    domains: ["fedskillstest.ct.digital"],
  },
};

export default nextConfig;
