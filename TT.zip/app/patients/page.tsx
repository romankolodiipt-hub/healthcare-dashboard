export default function PatientsPage() {
  return <div>Patients Page</div>;
}
