"use client";
import { useParams } from "next/navigation";
import { Patient } from "../types/types";
import { useContext } from "react";
import { PatientsContext } from "../context/Context";
import { convertToSlug } from "../utils/utils";
import { useState, useEffect } from "react";

export const useGetPatient = () => {
  const { slug } = useParams();

  const patients: Patient[] = useContext(PatientsContext) || [];

  return patients.find(({ name }) => {
    const patientSlug = convertToSlug(name);
    return patientSlug === slug;
  });
};

export const useResize = () => {
  const [tick, setCount] = useState(0);
  useEffect(() => {
    if (typeof window === "undefined") return;
    const trigger = () => {
      console.log("use resize");
      setCount((prev) => prev + 1);
    };
    window.addEventListener("resize", trigger);
    window.visualViewport?.addEventListener("resize", trigger);
    return () => {
      window.removeEventListener("resize", trigger);
      window.visualViewport?.removeEventListener("resize", trigger);
    };
  }, []);
  return tick;
};
