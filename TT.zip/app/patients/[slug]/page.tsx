import { DiagnosticColumn } from "@/src/components/DiagnosticColumn";
import { ProfileColumn } from "@/src/components/ProfileColumn";
// import { fetchData } from "@/src/utils/fetchData";
// import { convertToSlug } from "@/src/utils/utils";

// export async function generateStaticParams() {
//   const patients = await fetchData();
//   return patients.map(({ name }) => ({ slug: convertToSlug(name) }));
// }

export default async function PatientPage() {
  return (
    <>
      <DiagnosticColumn />
      <ProfileColumn />
    </>
  );
}
