export type Diagnostic = {
  name: string;
  description: string;
  status: string;
};

export type LabResult = string;

export type Months =
  | "January"
  | "February"
  | "March"
  | "April"
  | "May"
  | "June"
  | "July"
  | "August"
  | "September"
  | "October"
  | "November"
  | "December";

export type Level = "Lower than Average" | "Normal" | "Higher than Average";

export type Indicator = {
  value: number;
  levels: Level;
};

export type PatientsDiagnosisHistory = {
  month: Months;
  year: number;
  blood_pressure: {
    systolic: Indicator;
    diastolic: Indicator;
  };
  heart_rate: Indicator;
  respiratory_rate: Indicator;
  temperature: Indicator;
};

export type Patient = {
  name: string;
  gender: string;
  age: number;
  profile_picture: string;
  date_of_birth: string;
  phone_number: string;
  emergency_contact: string;
  insurance_type: string;
  diagnosis_history: PatientsDiagnosisHistory[];
  diagnostic_list: Diagnostic[];
  lab_results: LabResult[];
};

export type SelectedRange = "6" | "12" | "18";

export type ChartData = {
  months: string[] | [];
  diastolicValues: number[] | [];
  systolicValues: number[] | [];
};

export type DiagnosticTableHeader = (
  | "Problem/Diagnosis"
  | "Description"
  | "Status"
)[];

export type SelectOption = {
  value: string;
  name: string;
};
