"use client";
import React from "react";
import { useResize } from "@/src/hooks/hooks";

import { Patient } from "../types/types";
import { PatientsContext } from "../context/Context";

interface ProviderProps {
  children: React.ReactNode;
  data: Patient[];
}

export default function PatientsProvider({ children, data }: ProviderProps) {
  const tick = useResize();
  return (
    <PatientsContext.Provider value={data} key={tick}>
      {children}
    </PatientsContext.Provider>
  );
}
