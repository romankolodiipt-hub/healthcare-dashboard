"use client";

import { createContext, useContext } from "react";
import { Patient } from "../types/types";

export const PatientsContext = createContext<Patient[]>([]);

export const usePatients = () => {
  return useContext(PatientsContext);
};
